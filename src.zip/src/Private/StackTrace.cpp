#include "Stratum.h"
#include "StackTrace.h"

namespace Stratum::Tracing {
	StackTrace::StackTrace() noexcept
		: m_allocator(&m_defaultAllocator)
		, m_depth(0) {
		m_sentinel = m_allocator->allocate();
		STRATUM_ASSERT(m_sentinel != nullptr);
		m_sentinel->m_next = nullptr;
		m_tail = m_sentinel;
	}

	StackTrace::StackTrace(IFrameAllocator* po_Allocator) noexcept
		: m_allocator(po_Allocator ? po_Allocator : &m_defaultAllocator)
		, m_depth(0) {
		m_sentinel = m_allocator->allocate();
		STRATUM_ASSERT(m_sentinel != nullptr);
		m_sentinel->m_next = nullptr;
		m_tail = m_sentinel;
	}

	StackTrace::~StackTrace() noexcept {
		clear();
		m_allocator->deallocate(m_sentinel);
		m_sentinel = nullptr;
		m_tail = nullptr;
	}

	bool StackTrace::pushFrame(const Records::LogEntry& ro_Entry) noexcept {
		Frame* p_Frame = m_allocator->allocate();
		if (STRATUM_UNLIKELY(!p_Frame)) return false;
		p_Frame->m_next = nullptr;
		p_Frame->m_frame.emplace(ro_Entry);
		m_tail->m_next = p_Frame;
		m_tail = p_Frame;
		++m_depth;
		return true;
	}

	bool StackTrace::pushFrame(const Records::ExceptionEntry& ro_Entry) noexcept {
		Frame* p_Frame = m_allocator->allocate();
		if (STRATUM_UNLIKELY(!p_Frame)) return false;
		p_Frame->m_next = nullptr;
		p_Frame->m_frame.emplace(ro_Entry);
		m_tail->m_next = p_Frame;
		m_tail = p_Frame;
		++m_depth;
		return true;
	}

	bool StackTrace::pushFrame(const Records::TracerEntry& ro_Entry) noexcept {
		Frame* p_Frame = m_allocator->allocate();
		if (STRATUM_UNLIKELY(!p_Frame)) return false;
		p_Frame->m_next = nullptr;
		p_Frame->m_frame.emplace(ro_Entry);
		m_tail->m_next = p_Frame;
		m_tail = p_Frame;
		++m_depth;
		return true;
	}

	ProfilerTrace StackTrace::popFrame() noexcept {
		if (STRATUM_UNLIKELY(!m_sentinel->m_next))
			return ProfilerTrace{};

		Frame* p_Frame = m_sentinel->m_next;
		ProfilerTrace result = std::move(p_Frame->m_frame);

		if (m_tail == p_Frame)
			m_tail = m_sentinel;

		m_sentinel->m_next = p_Frame->m_next;
		m_allocator->deallocate(p_Frame);
		--m_depth;
		return result;
	}

	EntryKind StackTrace::peekKind() const noexcept {
		if (STRATUM_UNLIKELY(!m_sentinel->m_next)) return EntryKind::None;
		return m_sentinel->m_next->m_frame.kind();
	}

	bool   StackTrace::empty() const noexcept { return m_depth == 0; }
	size_t StackTrace::depth() const noexcept { return m_depth; }

	void StackTrace::clear() noexcept {
		Frame* p_Current = m_sentinel->m_next;
		while (p_Current) {
			Frame* p_Next = p_Current->m_next;
			p_Current->m_frame.destroy();
			m_allocator->deallocate(p_Current);
			p_Current = p_Next;
		}
		m_sentinel->m_next = nullptr;
		m_tail = m_sentinel;
		m_depth = 0;
	}
}